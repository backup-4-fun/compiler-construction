First run the lexer(cpp file)
Then run the parser(ipynb)
By default TC0 (testcase-0) is there in the code to give other
testcases in line number-135 of "lexer" change the file name.

TC0,T1,TC2,TC3 --> Testcases
ptable --> parsing table LL(1)
Tokens --> gives input to the parser(taken from lexer)
 
