#include<bits/stdc++.h>
using namespace std;

string reserved_words[]={"main","for","while","if","else if","else","int","float","char","string","true","false","print","scan","return","null"};
int bus=100;
const char* sq="'";
char cb[100];
char pb[100];
char delimit[]={'(',')','{','}',']','[',';',',','.'};
char isop[]={'=','+','*','/','-','>','<','%','!','|','&'};
string operate[]={"=","==","+","*","/","<=",">=","!=","-",">","<","%","!","|","&"};
vector<vector<string> > tokens;
int lnum=0;
vector<int> linenumber;
int isLetter(char c)
{
	if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z'))
		return 1;
	return 0;
}

int isNumeric(char c)
{
	if ((c >= '0') && (c <= '9'))
		return 1;

	return 0;
}

int isDelimiter(char q)
{
	for(int i=0;i<9;i++)
	{
		if(delimit[i]==q)
		{
			return 1;
		}
	}
	
	return 0;
}

int isOperator(char q)
{
	
	for(int i=0;i<11;i++)
	{
		if(isop[i]==q)
		{
			return 1;
		}
	}
	return 0;
}

string errfunction(string str)
{
	int i = 0, f = 0;
	while (i < 16)
	{
		if (str == reserved_words[i])
			return "Reserved_word";
		i++;
	}

	if (isDelimiter(str[0]))
	{
		return "Delimiter";
	}

	else if (isOperator(str[0]))
	{
		return "Operator";
	}

	else if (isNumeric(str[0]))
	{
		i = 0;
		if (str[0] == '0' && isNumeric(str[1]))
			return "Lexical error";

		while (isNumeric(str[i]))
		{
			i++;
		}
		if (str[i] == '.' && isNumeric(str[i + 1]))
		{
			i++;
			while (isNumeric(str[i]))
			{
				i++;
			}
			return "Float";
		}

		else if (str[i] == '.' && isLetter(str[i + 1]))
		{
			i += 2;
			while (isLetter(str[i]) == 1 || isNumeric(str[i]) == 1 || str[i] == '_')
			{
				i += 1;
			}

			return "Lexical error";
		}
		else
		{
			return "Integer";
		}
	}
    
	else if (str[0] == '"' || str[0]==sq[0])
	{
		return "String literal";
	}

	else if (isLetter(str[0]))
	{
		return "Identifier";
	}

	else
	{
		return "Lexical error";
	}
	return "lexical error";
}

int main()
{
	
	int p,q;
	p=0,q=0;
	FILE *fp;
	fp=fopen("TC0.txt","r");
	int fcc=0;// full comment checker
	string slink;
	int opeTrue=0;
	int linkTrue=0;
	int flagn=0;
	int shin1=0;
	int shin2=0;
	vector<string> sdum;
	vector<string> vect;
	while(fgets(cb,bus,fp)!=NULL)
	{
//		printf("*******************************\n");
//		printf("%s\n",cb);
		int tdu;
		
		vect.clear();
		//printf("%d\n",tdu);
		if((isNumeric(cb[q])==1||isLetter(cb[q])==1||cb[q]=='_')&&linkTrue==1)
		{
			while(isNumeric(cb[q])==1||isLetter(cb[q])==1 || cb[q] == '_')
			{
				
				slink+=cb[q];
				q++;
			}
		//	cout<<"---"<<slink<<"----\n";
			sdum.pop_back();
			sdum.push_back(slink);
		}
		//cout<<"q____"<<q<<"\n";
		if(opeTrue==1&&isOperator(cb[0])==1)
		{
			slink+=cb[0];
			sdum.pop_back();
			sdum.push_back(slink);
		}
		if(flagn==1)
		{
			tokens.push_back(sdum);
			linenumber.push_back(lnum);
			sdum.clear();
			flagn=0;
		}
		shin2=0;
		int i=0;
		tdu=cb[i];
		while(tdu==9)
		{
			p+=1;
			q=p;
			i+=1;
			tdu=cb[i];
		}
		while(1)
		{
			if(fcc==1)
			{
				while(cb[q]!='*'&&cb[q+1]!='/'&&q<bus)
				{
					q+=1;
					
				}
				if(q<bus)
				{
					shin1=0;
					q+=2;
					fcc=0;
					
				}
				
			}
			if(q>=bus)
			{
				break;	
			}	
			if(cb[q]=='\n')
			{
				flagn=1;
				lnum++;
				break;
			}
			if(cb[q]=='/'&&cb[q+1]=='/')
			{
				q=bus+1;
				flagn=1;
				lnum++;
				shin2=1;
				break;
			}
			if(cb[q]=='/'&&cb[q+1]=='*')
			{
				fcc=1;
				shin1=1;
				break;
			}
			if (isLetter(cb[q]) == 1)
			{
				p = q;
				q++;
				while (isLetter(cb[q]) == 1 || isNumeric(cb[q]) == 1 || cb[q] == '_' )
				{
					q += 1;
				}
				int i = p;
				string s = "";
				while ( i < q ) 
				{
					s = s + cb[i];
					i++;
				}
				i = 0;
				int f = 0;
			
				while (i < 11)
				{
					if (s == reserved_words[i])
						f = 1;
					i++;
				}
				//if (f == 1)
				//	//printf("  Reserved word");
				//else
				//	//printf("  Identifier");
				vect.push_back(s);

				//printf("\n");
				//q+=1;
				p = q;
			}

			else if (isNumeric(cb[q]) == 1)
			{
				int i = q;
				string s = "";
				q++;
				while (isNumeric(cb[q]))
				{
					q++;
				}
				if ( cb[q] == '.' && isNumeric(cb[q + 1]) )
				{
					q++;
					while (isNumeric(cb[q]))
					{
						q++;
					}
					while (i < q)
					{
						s = s + cb[i];
						//printf("%c", cb[i]);
						i++;
					}
					//printf("  Float\n");
				}
				else if (cb[q] == '.' && isLetter(cb[q + 1]))
				{
					q+=2;
					while (isLetter(cb[q]) == 1 || isNumeric(cb[q]) == 1 || cb[q] == '_')
					{
						q += 1;
					}
					while (i < q)
					{
						s = s + cb[i];
						//printf("%c", cb[i]);
						i++;
					}
					//printf("  Lexical error\n");
				}
				else
				{
					while (i < q)
					{
						s = s + cb[i];
						//printf("%c", cb[i]);
						i++;
					}
					//printf("  Integer\n");
				}
				vect.push_back(s);
				p = q;
			}

			else if(isDelimiter(cb[q])==1)
			{
				string s = "";
				s = s + cb[q];
				vect.push_back(s);
				//printf("%c",cb[q]);
				//printf("  Delimiter\n");
				p+=1;
				q+=1;
				
			}
			else if(isOperator(cb[q])==1)
			{
				string s = "";
				if (isOperator(cb[q + 1]) == 1)
				{
					int f = 0;
					s = s + cb[q];
					s = s + cb[q + 1];
					for (int j = 0; j < 15; j++)
					{
						if (s == operate[j])
							f = 1;
					}
					if (f == 1)
					{
						//printf("%c%c", cb[q], cb[q + 1]);
						//printf("  Operator\n");
						p += 2;
						q += 2;
					}
					else
					{
						s = "";
						s += cb[q];
						//printf("%c", cb[q]);
						//printf("  Operator\n");
						p += 1;
						q += 1;
					}
				}
				else
				{
					s = s + cb[q];
					//printf("%c",cb[q]);
					//printf("  Operator\n");
					p+=1;
					q+=1;
					
				}
				vect.push_back(s);
			}
			else if(cb[q]==' ')
			{
				int cnt=0;
				
				while(cb[q]==' ')
				{
					q+=1;
					cnt+=1;
				}
				
				//q+=1;
				p=q;
				if(cnt>10)
				{
					break;
				}
			}
			else if(cb[q]=='"')
			{
				string s = "";
				q+=1;
				while(cb[q]!='"')
				{
					q+=1;
				}
				for(int i=p;i<=q;i++)
				{
					s = s + cb[i];
					//printf("%c",cb[i]);
				}
				//printf("  String literal\n");
				vect.push_back(s);
				q+=1;
				p=q;
			}
			else if(cb[q]==sq[0])
			{
				q+=1;
				string s ="";
				s+=cb[q-1];
				while(cb[q]!=sq[0])
				{
					s=s+cb[q];
					q+=1;
				}
				s=s+cb[q];
				//printf("\n");
				vect.push_back(s);
				q+=1;
				p=q;
			}
			else if(cb[q]=='\n')
			{
				break;
			}
			else if (cb[q] == '\0')
			{
				break;
			}
			else
			{
				//printf("%c  Lexical error\n",cb[q]);
				string s = "";
				s = s + cb[q];
				vect.push_back(s);
				q++;
				p = q;
			}
			
		//printf("dummy\n");	
		}
		
		q = 0;
		p = 0;
		if(shin1==1)
		{
			for(int i=0;i<bus;i++)
			{
				if(cb[i]=='\n')
				{
					lnum++;
					flagn=1;
				}
			}
		}
		
		sdum.insert(sdum.end(), vect.begin(), vect.end());;
		linkTrue=0;
		
		/*for(int i=0;i<vect.size();i++)
		{
			cout<<sdum[i]<<"";
		}*/
		opeTrue=0;
		string link;
		int linknum=bus-2;
		string debug;
		//cout<<"___"<<cb[linknum]<<"\n";
		if(isLetter(cb[linknum])==1||isNumeric(cb[linknum])==1 || cb[linknum] == '_')
		{
			linkTrue=1;
			//cout<<"dog\n";
			while(isLetter(cb[linknum])==1||isNumeric(cb[linknum])==1 || cb[linknum] == '_')
			{
				
				debug+=cb[linknum];
				linknum--;
			}
			//cout<<"---"<<debug<<"----\n";
		}
		
		int temp=linknum+1;
		while(temp<bus-1)
		{
			link+=cb[temp];
			temp++;
		}
		
		if((isOperator(cb[99])==1)&&(isOperator(cb[98])==0))
		{
			link+=cb[99];
			opeTrue=1;
		}
		slink=link;
		//printf("main sentence-> %s\n",cb);
		for(int i=0;i<bus;i++)
		{
			pb[i]=cb[i];
			cb[i]=' ';
		}
		
	}
	linenumber.push_back(lnum+1);
	tokens.push_back(sdum);
	//cout << "\n\n\n";
	for (int i = 0; i < tokens.size(); i++)
	{
		//cout<<linenumber[i]<<"-->";
		for (int j = 0; j < tokens[i].size(); j++)
		{
			cout<<"Line num: " <<linenumber[i] << "-->  " << tokens[i][j]  << "  -->  " << errfunction(tokens[i][j]) << "\n";
		}
	}
	
	fclose(fp);
	//file handling
	fstream fio;
	string line;
	fio.open("tokens.txt",ios::trunc | ios::out | ios::in);
	for (int i = 0; i < tokens.size(); i++)
	{
		//cout<<linenumber[i]<<"-->";
		for (int j = 0; j < tokens[i].size(); j++)
		{
			if( errfunction(tokens[i][j]) == "Identifier")
			{
				fio<<"Id"<<" ";
			}
			else if (errfunction(tokens[i][j]) == "Integer")
			{
				fio<<"Integer"<<" ";
			}
			else if (errfunction(tokens[i][j]) == "Float")
			{
				fio<<"Float"<<" ";
			}
			else if (errfunction(tokens[i][j]) == "String literal")
			{
				fio<<"SL"<<" ";
			}
			else 
			{
				fio<<tokens[i][j]<<" ";
			}
		}
	}
	fio.close();
	return 0;
}
