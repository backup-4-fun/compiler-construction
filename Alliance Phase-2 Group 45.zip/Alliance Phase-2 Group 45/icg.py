from platform import java_ver
from prettytable import PrettyTable # prettytable is used to generate the table 

def ifFunction():    # function to be called when if condition is encountered
    x1 = PrettyTable()
    code = open('TC0.txt','r') #opening the if.txt to read the input
    lines = code.read().splitlines()
    individual_lines = []

    for entry in lines:   #splitting the input and appending them to individual lines
        x = []
        x = entry.split(" ")
        individual_lines.append(x)

    goto,code1 = [],[]
    for i in range(len(lines)):
        a = []
        if 'if' in lines[i]:    #handling mechanism if "if" keyword is found
            a.append(lines[i])  
            a.append('goto()')
            code1.append(a)
        elif 'return' in lines[i]:
            a.append('t1')
            a.append('=')
            a.append(individual_lines[i][-1][:len(individual_lines[i][-1])-1])
            code1.append(a)
            if('if' in lines[i-1]):
                code1.append(['goto()'])
            else:
                goto.append(len(code1))
        elif 'else' not in lines[i]:
            a.append(lines[i])
            code1.append(a)

    goto.append(len(code1)+1)

    for i in range(len(code1)):
        if 'if' in code1[i][0]:
            code1[i][0] = code1[i][0].replace('A<B','!A<B')

    j=-1
    for i in range(len(code1)):
        if 'goto()' in code1[i][0]:
            j+=1
            code1[i][0] = code1[i][0].replace('goto()','goto('+str(goto[j])+')')
        elif 'goto()' in code1[i][-1]:
            j+=1
            code1[i][-1] = code1[i][-1].replace('goto()','goto('+str(goto[j])+')')

    x1.field_names = ['Index','Code']  #adding table field names
    for i in range(len(code1)):
        code2 = ""
        for j in code1[i]:
            code2 += j
        x1.add_row([i+1,code2])

    x1.add_row([len(code1)+1,"END"])
    print('\n\nIf condition encountered :')
    print(x1)

OPERATORS = set(['+', '-', '*', '/', '(', ')'])  #declaring the operators
PRI = {'+':1, '-':1, '*':2, '/':2}    #assigning the priorities


def i_to_p(formula): #calculating the postfix
    stack = [] # only pop when the coming op has priority 
    output = ''
    for ch in formula:
        if ch not in OPERATORS:
            output += ch
        elif ch == '(':
            stack.append('(') #appendinf '('
        elif ch == ')':
            while stack and stack[-1] != '(':
                output += stack.pop()
            stack.pop() # pop '('
        else:
            while stack and stack[-1] != '(' and PRI[ch] <= PRI[stack[-1]]:
                output += stack.pop()  # pop the stack
            stack.append(ch)
    # leftover
    stack.reverse()
    for i in stack:
        output +=i
    return output

### THREE ADDRESS CODE GENERATION ###
def generate3AC(pos):
	exp_stack = []  #declare the stack
	t = 1
	
	for i in pos:
		if i not in OPERATORS: #if i is not present in operators append it to the stack
			exp_stack.append(i)
		else:
			print(f't{t} := {exp_stack[-2]} {i} {exp_stack[-1]}')
			exp_stack=exp_stack[:-2]
			exp_stack.append(f't{t}')
			t+=1

file = open('TC0.txt','r')  #read the input from input.txt

j = 0
var=4
for line in file:
   s = ""
   j = j+1
   flag = False         #set the boolen flag to False
   word = ""
   
   gg=0
   if(var<4):                      
       file1 = open("output2.txt",'a+')  #append to the "if.txt" file
       file1.write(line)
       var+=1
       gg=1
       if (var==4):
           ifFunction() #call the ifFunction when we reach the end of if function
           file1.close() #close the file 
           gg=0
          
    
   if(gg==1):
        continue

   
   flag_if = False
   for ch in line:
       if(ch!=' ' and ch!='\n' and ch!=';'):
         s =  s + ch
       else:
         word = ""
       if(ch == '=' or ch == '+' or ch == '-' or ch == '*' or ch == '/'):
         word = ""   #when we encounter arithmatic operators, set word to NULL
         flag = True
       else:
         word = word + ch
       if(word == "if"):     #if the if condition is present set flag_if value to TRUE
           var=1
           flag_if = True
       if(flag_if):
           file1 = open("output2.txt",'w') #IF THE IF KEYWORD IS FOUND WRITE TO THE IF.TXT FILE
           flag = False
           i = 0
           file1.write(line)
           break
   
        
      

   if(flag):
    pos = i_to_p(s)    #passing the current line to the i_to_p function
    generate3AC(pos)   #generate the three address code

