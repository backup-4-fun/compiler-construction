
'''
TO DO LIST
1) file handling in c
2) checking the .csv file input and output
3) parsing
4) error handling

'''

f=open("tokens.txt",'r')
#f=open("test.txt",'r')
s=f.read()
sid=s.split(" ")
sid.append('$')
print(sid) #lexer outputs


from openpyxl import load_workbook
workbook = load_workbook(filename="ptable.xlsx")
sheet = workbook.active
#type(sheet.cell(row=1,column=1).value)


rows={'S':2,'Co':3,'Prog':4,'Stat':5,'Dec':6,'Eq':7,'X':8,'F':9,'In':10,'Cond':11,'Op':12,'W':13,'Con':14,'P':15,'K':16,'Num':17,'DT':18,'O':19,'cop':20,'AIO':21,'$':22}
cols={'main':2,'(':3,')':4,';':5,'Id':6,'=':7,'for':8,'while':9,'if':10,'else':11,'{':12,'}':13,'Float':14,'Integer':15,'SL':16,'int':17,'float':18,'string':19,'char':20,'+':21,'-':22,'*':23,'/':24,'%':25,'>':26,'>=':27,'==':28,'<=':29,'<':30,'!=':31,'$':32}


inp=[]
inp=sid
s=['$','Co'] #stack
n=len(inp)
cnt=0
safe_s=[]
safe_i=[]
file = open("output.txt", "w")
temp = "INPUT is "+' '.join(map(str, inp))+"in STACK"+' '.join(map(str, s[::-1]))+"\n"
file.write(temp)


#print("INPUT->",' '.join(map(str, inp)),"STACK->",' '.join(map(str, s[::-1]))) 
while len(s)>1 or len(inp)>0 :
    if inp[0]=='':
        inp.pop(0)
    if len(s)==1 and len(inp)==1:
        temp = "INPUT is "+' '.join(map(str, inp))+"in STACK"+' '.join(map(str, s[::-1]))+"\n"
        file.write(temp)
        #print("INPUT->",' '.join(map(str, inp)),"STACK->",' '.join(map(str, s[::-1])))
        break
    if s[-1]=='':
        s.pop()
    elif s[-1]=='null':
        s.pop()
    a=s[-1]
    b=inp[0]
    #print("at start",a,b)
    if a==b:
        #print("in if ","a->",a,"b->",b,'match->','match')
        s.pop()
        inp=inp[1:]
    else:
        
        try:
            r=rows[a]
            c=cols[b]
            dig=sheet.cell(row=r,column=c).value #taken from table
        except:
            s.pop()
            file.write("ERROR-SYNCH\n")
            #print("ERROR-SYNCH")
            continue
        if dig=="synch":
            s.pop()
            file.write("ERROR-SYNCH\n")
        elif dig=="skip":
            inp=inp[1:]
            file.write("ERROR-SYNCH\n")
        else:
            ldig=dig.split(" ")
            s.pop()
            s.extend(ldig[::-1])
    temp = "INPUT is"+' '.join(map(str, inp))+"in STACK"+' '.join(map(str, s[::-1]))+"\n"
    file.write(temp)
    cnt+=1
file.close()





