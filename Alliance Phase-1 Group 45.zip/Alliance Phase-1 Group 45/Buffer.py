import re

class Buffer:
    def load_buffer(self):
        
        
        finput = open('Testcase1.c', "r")
         
        foutput = open('Testcase1.c', "r+")
        for line in finput:
            #cmtrem(line)
            l = line.split("//")
            l[0] = l[0].replace(" ", "")
            if len(l) > 1:
                l[0] += "\n"
            if l[0].rstrip():
                foutput.write(l[0])
        text = foutput.readline()
        buffer = []
        cont = 1

        # The buffer size can be changed by changing cont
        while text != "":
            buffer.append(text)
            text = foutput.readline()
            cont += 1

            if cont == 10 or text == '':
                # Return a full buffer
                buf = ''.join(buffer)
                cont = 1
                yield buf

                # Reset the buffer
                buffer = []

        
