# Alliance Phase -1 :  Lexical Analyzer & Parser ; Scanner

This is a simple lexical analyzer for the C language. The repository contains an example program in C for testing.

This basically identifies tokens , keep track of the line , Eliminates Comments and While spaces.

Run Command : python Alliance.py
